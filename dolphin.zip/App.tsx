import React, { useState, useEffect } from 'react';
import { Truck, LogOut, AlertTriangle, WifiOff } from 'lucide-react';
import { UserRole, Product, CartItem, Order, User, Store, Message, Review } from './types';
import { MOCK_PRODUCTS, MOCK_STORES } from './constants';
import { MerchantView } from './components/MerchantView';
import { ShopperView } from './components/ShopperView';
import { AuthView } from './components/AuthView';
import { SplashScreen } from './components/SplashScreen';
import { db, auth, storage } from './services/firebase';
import { collection, getDocs, setDoc, doc, getDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, updateProfile, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const App: React.FC = () => {
  // Splash Screen State
  const [showSplash, setShowSplash] = useState(true);

  // User State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [isDbConnected, setIsDbConnected] = useState(true);
  
  // Theme State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('dolphin_theme');
      // Default to Light Mode (false) unless 'dark' is explicitly saved
      return saved === 'dark';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('dolphin_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('dolphin_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  // Handle Splash Screen Timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3000); // Show splash for at least 3 seconds
    return () => clearTimeout(timer);
  }, []);

  // Data States
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_products');
      return saved ? JSON.parse(saved) : MOCK_PRODUCTS;
    } catch (e) { return MOCK_PRODUCTS; }
  });

  const [stores, setStores] = useState<Store[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_stores');
      return saved ? JSON.parse(saved) : MOCK_STORES;
    } catch (e) { return MOCK_STORES; }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_orders');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_messages');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_reviews');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('dolphin_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  // FIREBASE AUTHENTICATION LISTENER
  useEffect(() => {
    if (!auth) {
      setInitializing(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // User is signed in, fetch additional details from Firestore (like Role)
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data() as User;
            setCurrentUser(userData);
          } else {
             // Fallback if doc doesn't exist (e.g. signup created auth but failed db write)
             setCurrentUser({
               id: user.uid,
               name: user.displayName || 'User',
               email: user.email || '',
               role: UserRole.SHOPPER, // Default
               photoURL: user.photoURL || undefined
             });
          }
          setIsDbConnected(true);
        } catch (error: any) {
          console.error("Error fetching user details:", error);
          
          if (error.code === 'permission-denied') {
             setIsDbConnected(false);
          }

          // CRITICAL FALLBACK: If Firestore fails (network/permissions), still log the user in
          setCurrentUser({
            id: user.uid,
            name: user.displayName || 'User',
            email: user.email || '',
            role: UserRole.SHOPPER,
            photoURL: user.photoURL || undefined
          });
        }
      } else {
        // User is signed out
        setCurrentUser(null);
      }
      setInitializing(false);
    });

    return () => unsubscribe();
  }, []);

  // FIREBASE DATA SYNC
  useEffect(() => {
    const syncData = async () => {
      if (!db || !currentUser || !isDbConnected) return; // Only sync if logged in and connected

      try {
        // Products
        const productsSnapshot = await getDocs(collection(db, 'products'));
        if (!productsSnapshot.empty) {
           const dbProducts = productsSnapshot.docs.map(doc => doc.data() as Product);
           setProducts(dbProducts);
        }

        // Stores
        const storesSnapshot = await getDocs(collection(db, 'stores'));
        if (!storesSnapshot.empty) {
           const dbStores = storesSnapshot.docs.map(doc => doc.data() as Store);
           setStores(dbStores);
        }

        // Orders
        const ordersSnapshot = await getDocs(collection(db, 'orders'));
        if (!ordersSnapshot.empty) {
           const dbOrders = ordersSnapshot.docs.map(doc => doc.data() as Order);
           setOrders(dbOrders);
        }

        // Reviews
        const reviewsSnapshot = await getDocs(collection(db, 'reviews'));
        if (!reviewsSnapshot.empty) {
          const dbReviews = reviewsSnapshot.docs.map(doc => doc.data() as Review);
          setReviews(dbReviews);
        }
        
        // If we reached here, connection is good
        setIsDbConnected(true);

      } catch (error: any) {
        console.error("Error syncing with Firebase:", error);
        if (error.code === 'permission-denied') {
          setIsDbConnected(false);
        }
      }
    };

    if (currentUser) {
      syncData();
    }
  }, [currentUser, isDbConnected]);

  // Helpers to save to Firestore
  const saveToFirebase = async (collectionName: string, id: string, data: any) => {
    if (!db || !isDbConnected) return; // Don't try to save if we know we have no permissions
    try {
      await setDoc(doc(db, collectionName, id), data);
    } catch (e: any) {
      console.error(`Error saving to ${collectionName}:`, e);
      if (e.code === 'permission-denied') {
         setIsDbConnected(false);
      }
    }
  };

  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  // Save data to local storage whenever it changes (backup)
  useEffect(() => localStorage.setItem('dolphin_products', JSON.stringify(products)), [products]);
  useEffect(() => localStorage.setItem('dolphin_stores', JSON.stringify(stores)), [stores]);
  useEffect(() => localStorage.setItem('dolphin_orders', JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.setItem('dolphin_messages', JSON.stringify(messages)), [messages]);
  useEffect(() => localStorage.setItem('dolphin_cart', JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem('dolphin_reviews', JSON.stringify(reviews)), [reviews]);

  const handleLogin = async (email: string, pass: string) => {
    setAuthLoading(true);
    setAuthError(null);
    
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      // Logic handled by onAuthStateChanged
    } catch (error: any) {
      console.error("Login Error:", error);
      const errorCode = error.code;
      if (errorCode === 'auth/invalid-email' || errorCode === 'auth/invalid-credential' || errorCode === 'auth/user-not-found' || errorCode === 'auth/wrong-password') {
        setAuthError('Incorrect email or password.');
      } else if (errorCode === 'auth/too-many-requests') {
        setAuthError('Too many attempts. Please try again later.');
      } else if (errorCode === 'auth/network-request-failed') {
        setAuthError('Network error. Check your internet connection.');
      } else {
        setAuthError(error.message || 'Failed to login');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Optimistic user object in case DB fails
      const newUser: User = {
        id: user.uid,
        name: user.displayName || 'User',
        email: user.email || '',
        role: UserRole.SHOPPER, // Default role for Google Sign In
        photoURL: user.photoURL || undefined
      };

      // Check if user doc exists in Firestore, if not create it
      // Wrap in try-catch to handle permission errors silently during login
      try {
        const userDocRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);

        if (!userDoc.exists()) {
          await setDoc(userDocRef, newUser);
        }
      } catch (e: any) {
        console.warn("Could not create/fetch user in DB (likely permissions). Using auth profile.", e);
        if (e.code === 'permission-denied') setIsDbConnected(false);
      }
      
      // If onAuthStateChanged fails to get DB user, it will use Auth details, which matches newUser
    } catch (error: any) {
      console.error("Google Login Error:", error);
      if (error.code === 'auth/popup-closed-by-user') {
        // User closed popup, no need to show error
      } else {
        setAuthError(error.message || 'Failed to sign in with Google');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignup = async (name: string, email: string, pass: string, role: UserRole, photo: File | null) => {
    setAuthLoading(true);
    setAuthError(null);
    
    try {
      // 1. Create User in Auth
      const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
      const user = userCredential.user;
      
      let photoURL = '';

      // 2. Upload Profile Photo if exists
      if (photo && storage) {
        try {
          const storageRef = ref(storage, `profile_photos/${user.uid}`);
          await uploadBytes(storageRef, photo);
          photoURL = await getDownloadURL(storageRef);
        } catch (uploadError) {
          console.error("Error uploading photo:", uploadError);
          // Continue signup even if photo upload fails
        }
      }

      // 3. Update Auth Profile
      await updateProfile(user, {
        displayName: name,
        photoURL: photoURL || null
      });

      // 4. Create User Document in Firestore with Role
      const newUser: User = {
        id: user.uid,
        name,
        email,
        role,
        photoURL
      };

      try {
        await setDoc(doc(db, 'users', user.uid), newUser);
      } catch (e: any) {
        console.warn("DB Permission denied during signup. Proceeding with local state.");
        if (e.code === 'permission-denied') setIsDbConnected(false);
      }
      
      setCurrentUser(newUser);

      // 5. Auto-create a default store for new merchants
      if (role === UserRole.MERCHANT) {
        const newStore: Store = {
          id: Math.random().toString(36).substr(2, 9),
          ownerId: user.uid,
          name: `${name}'s Store`,
          type: 'General',
          address: 'Main Market',
          phoneNumber: ''
        };
        setStores(prev => [...prev, newStore]);
        saveToFirebase('stores', newStore.id, newStore);
      }

    } catch (error: any) {
      console.error("Signup Error:", error);
      if (error.code === 'auth/email-already-in-use') {
        setAuthError('Email already registered');
      } else if (error.code === 'auth/weak-password') {
        setAuthError('Password should be at least 6 characters');
      } else {
        setAuthError(error.message || 'Failed to sign up');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setCart([]);
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  const handleUpdateProfile = (updates: Partial<User>) => {
    if (!currentUser) return;
    
    const updatedUser = { ...currentUser, ...updates };
    setCurrentUser(updatedUser);
    
    saveToFirebase('users', currentUser.id, updatedUser);
  };

  const handleAddProduct = (product: Product) => {
    setProducts(prev => [...prev, product]);
    saveToFirebase('products', product.id, product);
  };

  const handleAddStore = (store: Store) => {
    setStores(prev => [...prev, store]);
    saveToFirebase('stores', store.id, store);
  };

  const handleUpdateStore = (updatedStore: Store) => {
    setStores(prev => prev.map(s => s.id === updatedStore.id ? updatedStore : s));
    saveToFirebase('stores', updatedStore.id, updatedStore);

    // Update denormalized store data in products
    const updatedProducts = products.map(p => {
      if (p.storeId === updatedStore.id) {
        const updated = {
          ...p,
          storeName: updatedStore.name,
          storeType: updatedStore.type
        };
        saveToFirebase('products', p.id, updated);
        return updated;
      }
      return p;
    });
    setProducts(updatedProducts);
  };

  const handleDeleteStore = (storeId: string) => {
    // Optimistic UI update
    setStores(prev => prev.filter(s => s.id !== storeId));
    // Cascade delete products
    setProducts(prev => prev.filter(p => p.storeId !== storeId));
    
    // Attempt delete in firebase (requires logic in saveToFirebase or separate delete function)
    // For this simplified version we're relying on local storage sync
  };

  const handleSendMessage = (text: string, receiverId: string) => {
    if (!currentUser) return;
    const newMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: currentUser.id,
      receiverId,
      content: text,
      timestamp: Date.now(),
      senderName: currentUser.name
    };
    setMessages(prev => [...prev, newMessage]);
    saveToFirebase('messages', newMessage.id, newMessage);
  };

  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const handleCheckout = (address: string, phone: string, paymentMethod: string) => {
    if (!currentUser) return;
    
    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9),
      items: [...cart],
      total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      status: 'pending',
      timestamp: Date.now(),
      customerName: currentUser.name,
      address: address,
      phoneNumber: phone,
      paymentMethod: paymentMethod,
    };
    setOrders(prev => [newOrder, ...prev]);
    saveToFirebase('orders', newOrder.id, newOrder);
    setCart([]);
    alert(`Order placed successfully via ${paymentMethod}! A merchant will review it shortly.`);
  };

  const handleCancelOrder = (orderId: string) => {
    const updatedOrders = orders.map(o => o.id === orderId ? { ...o, status: 'cancelled' as const } : o);
    setOrders(updatedOrders);
    const order = updatedOrders.find(o => o.id === orderId);
    if (order) saveToFirebase('orders', order.id, order);
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    const updatedOrders = orders.map(o => o.id === orderId ? { ...o, status } : o);
    setOrders(updatedOrders);
    const order = updatedOrders.find(o => o.id === orderId);
    if (order) saveToFirebase('orders', order.id, order);
  };

  const handleAddReview = (review: Review) => {
    setReviews(prev => [review, ...prev]);
    saveToFirebase('reviews', review.id, review);
  };

  // RENDER: SPLASH SCREEN OR MAIN APP
  if (showSplash || initializing) {
     return <SplashScreen />;
  }

  // Render Auth View if not logged in
  if (!currentUser) {
    return (
      <AuthView 
        onLogin={handleLogin} 
        onSignup={handleSignup} 
        onGoogleLogin={handleGoogleLogin}
        error={authError}
        isLoading={authLoading}
        onErrorClear={() => setAuthError(null)}
      />
    );
  }

  return (
    <div className="transition-colors duration-200">
      {/* DB Connection Error Banner */}
      {!isDbConnected && (
        <div className="bg-rose-600 text-white px-4 py-2 text-xs font-bold flex items-center justify-center gap-2 sticky top-0 z-[100]">
          <WifiOff size={14} />
          Database Access Denied: Check Firebase Firestore Rules. App is running in Local Storage Mode.
        </div>
      )}

      {/* Logout Button (Desktop) */}
      <div className="fixed bottom-4 left-4 z-50 hidden md:block">
        <button 
          onClick={handleLogout}
          className="bg-slate-800 dark:bg-slate-700 text-white px-4 py-2 rounded-full text-xs font-medium shadow-lg hover:bg-slate-700 dark:hover:bg-slate-600 transition-all flex items-center gap-2 opacity-50 hover:opacity-100"
        >
          <LogOut size={14} />
          Log Out ({currentUser.name})
        </button>
      </div>

      {currentUser.role === UserRole.MERCHANT ? (
        <MerchantView 
          products={products} 
          orders={orders}
          stores={stores}
          currentUser={currentUser}
          onAddProduct={handleAddProduct}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          onAddStore={handleAddStore}
          onUpdateStore={handleUpdateStore}
          messages={messages}
          onSendMessage={handleSendMessage}
          onLogout={handleLogout}
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          onDeleteStore={handleDeleteStore}
        />
      ) : (
        <ShopperView 
          products={products} 
          cart={cart} 
          orders={orders}
          stores={stores}
          onAddToCart={handleAddToCart}
          onRemoveFromCart={handleRemoveFromCart}
          onCheckout={handleCheckout}
          onCancelOrder={handleCancelOrder}
          currentUser={currentUser}
          onUpdateProfile={handleUpdateProfile}
          messages={messages}
          onSendMessage={handleSendMessage}
          onLogout={handleLogout}
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          reviews={reviews}
          onAddReview={handleAddReview}
        />
      )}
      
      {/* Global Order Status Notification for Shopper */}
      {currentUser.role === UserRole.SHOPPER && orders.filter(o => o.customerName === currentUser.name).length > 0 && (
        <div className="fixed bottom-20 md:bottom-4 right-4 z-40 w-80 bg-white dark:bg-slate-800 rounded-lg shadow-xl border border-slate-200 dark:border-slate-700 p-4 hidden md:block">
          <div className="flex items-center gap-3 mb-2">
            <Truck className="text-indigo-600 dark:text-indigo-400" size={20} />
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">Latest Order Status</h4>
          </div>
          {(() => {
            const latestOrder = orders.filter(o => o.customerName === currentUser.name)[0];
            return (
              <>
                <div className="text-sm text-slate-600 dark:text-slate-300">
                  Order #{latestOrder.id.slice(0,6)} is <span className={`font-bold ${latestOrder.status === 'cancelled' ? 'text-rose-600 dark:text-rose-400' : 'text-indigo-600 dark:text-indigo-400'}`}>{latestOrder.status.toUpperCase()}</span>
                </div>
                {latestOrder.status !== 'cancelled' && (
                  <div className="w-full bg-slate-100 dark:bg-slate-700 h-1.5 mt-3 rounded-full overflow-hidden">
                    <div 
                      className="bg-indigo-600 dark:bg-indigo-500 h-full transition-all duration-500" 
                      style={{ 
                        width: latestOrder.status === 'pending' ? '25%' : 
                              latestOrder.status === 'preparing' ? '50%' : 
                              latestOrder.status === 'delivering' ? '75%' : '100%' 
                      }}
                    ></div>
                  </div>
                )}
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
};

export default App;