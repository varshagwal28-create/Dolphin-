import React, { useState, useEffect, useRef } from 'react';
import { Search, ShoppingCart, MapPin, Sparkles, X, Plus, Store, ChevronLeft, ChevronDown, Phone, Home, Facebook, Twitter, Instagram, Linkedin, Package, Clock, AlertCircle, User, Save, MessageCircle, Send, Bell, CreditCard, Wallet, Banknote, Sun, Moon, Star, ExternalLink, Zap, ArrowRight, Tag, LogOut, Filter, ShieldCheck, Map } from 'lucide-react';
import { Product, CartItem, StoreType, Order, User as UserType, Store as StoreModel, Message, Review } from '../types';
import { STORE_TYPES, STORE_CATEGORIES, STORE_IMAGES } from '../constants';
import { Button } from './Button';
import { getShopperRecommendations } from '../services/geminiService';

interface ShopperViewProps {
  products: Product[];
  cart: CartItem[];
  orders: Order[];
  stores: StoreModel[];
  onAddToCart: (product: Product) => void;
  onRemoveFromCart: (productId: string) => void;
  onCheckout: (address: string, phone: string, paymentMethod: string) => void;
  onCancelOrder: (orderId: string) => void;
  currentUser: UserType;
  onUpdateProfile: (data: Partial<UserType>) => void;
  messages: Message[];
  onSendMessage: (text: string, receiverId: string) => void;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  reviews: Review[];
  onAddReview: (review: Review) => void;
}

export const ShopperView: React.FC<ShopperViewProps> = ({ 
  products, 
  cart,
  orders,
  stores,
  onAddToCart, 
  onRemoveFromCart, 
  onCheckout,
  onCancelOrder,
  currentUser,
  onUpdateProfile,
  messages,
  onSendMessage,
  onLogout,
  isDarkMode,
  toggleTheme,
  reviews,
  onAddReview
}) => {
  const [selectedStoreType, setSelectedStoreType] = useState<StoreType | 'All'>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStoreId, setSelectedStoreId] = useState<string | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMessagesOpen, setIsMessagesOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [activeChatPartnerId, setActiveChatPartnerId] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');

  // Review State
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [newReviewRating, setNewReviewRating] = useState(0);
  const [newReviewComment, setNewReviewComment] = useState('');

  const [aiQuery, setAiQuery] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [highlightedProductIds, setHighlightedProductIds] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Location State
  const [location, setLocation] = useState('Indore');
  const [isLocationOpen, setIsLocationOpen] = useState(false);
  const [locationSearch, setLocationSearch] = useState('');

  const cities = [
    'Indore', 'Bhopal', 'Rewa', 'Satna', 'Mumbai', 'Delhi', 'Pune', 'Gujrat', 
    'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Bangalore', 'Hyderabad'
  ];

  const filteredLocations = cities.filter(city => 
    city.toLowerCase().includes(locationSearch.toLowerCase())
  );

  // Checkout Form State
  const [checkoutName, setCheckoutName] = useState(currentUser.name || '');
  const [checkoutPhone, setCheckoutPhone] = useState(currentUser.phoneNumber || '');
  const [checkoutStreet, setCheckoutStreet] = useState(currentUser.address || '');
  const [checkoutCity, setCheckoutCity] = useState(location);
  const [checkoutZip, setCheckoutZip] = useState('');
  const [checkoutInstructions, setCheckoutInstructions] = useState('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('COD');

  const paymentMethods = [
    { id: 'PayPal', name: 'PayPal', icon: CreditCard },
    { id: 'Paytm', name: 'Paytm', icon: Wallet },
    { id: 'Google Pay', name: 'Google Pay', icon: Wallet },
    { id: 'COD', name: 'Cash on Delivery', icon: Banknote },
  ];

  // Profile Form State
  const [profileForm, setProfileForm] = useState({
    name: currentUser.name,
    phoneNumber: currentUser.phoneNumber || '',
    address: currentUser.address || '',
    bio: currentUser.bio || ''
  });

  useEffect(() => {
    // Sync checkout form with profile if profile updates
    if (currentUser.address && !checkoutStreet) setCheckoutStreet(currentUser.address);
    if (currentUser.phoneNumber && !checkoutPhone) setCheckoutPhone(currentUser.phoneNumber);
    if (currentUser.name && !checkoutName) setCheckoutName(currentUser.name);
    
    // Sync profile form
    setProfileForm({
      name: currentUser.name,
      phoneNumber: currentUser.phoneNumber || '',
      address: currentUser.address || '',
      bio: currentUser.bio || ''
    });
  }, [currentUser]);

  useEffect(() => {
    if (isMessagesOpen && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isMessagesOpen, activeChatPartnerId]);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Message Helpers
  const getStoreByOwnerId = (ownerId: string) => stores.find(s => s.ownerId === ownerId);
  const getStoreByProductId = (storeId?: string) => stores.find(s => s.id === storeId);

  // Filter messages for current user
  const myMessages = messages.filter(m => m.senderId === currentUser.id || m.receiverId === currentUser.id);
  
  // Get unique contacts (Store Owners)
  const contactIds: string[] = Array.from(new Set(myMessages.map(m => m.senderId === currentUser.id ? m.receiverId : m.senderId)));
  
  // Current chat messages
  const activeChatMessages = myMessages
    .filter(m => 
      (m.senderId === currentUser.id && m.receiverId === activeChatPartnerId) || 
      (m.senderId === activeChatPartnerId && m.receiverId === currentUser.id)
    )
    .sort((a, b) => a.timestamp - b.timestamp);

  const handleSendMessageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activeChatPartnerId) return;
    onSendMessage(messageInput, activeChatPartnerId);
    setMessageInput('');
  };

  const openChatWithStore = (storeId?: string) => {
    const store = getStoreByProductId(storeId);
    if (store) {
      setActiveChatPartnerId(store.ownerId);
      setIsMessagesOpen(true);
    } else {
      alert("Cannot chat with this store at the moment.");
    }
  };

  const unreadCount = myMessages.filter(m => m.receiverId === currentUser.id).length;

  const filteredProducts = products.filter(p => {
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = !query || 
                          p.name.toLowerCase().includes(query) || 
                          p.description.toLowerCase().includes(query) ||
                          p.category.toLowerCase().includes(query);
    
    const isHighlighted = highlightedProductIds.length === 0 || highlightedProductIds.includes(p.id);

    // Location filtering
    const storeForProduct = stores.find(s => s.id === p.storeId);
    const matchesLocation = location === 'Current Location' || 
                            (storeForProduct && storeForProduct.address.toLowerCase().includes(location.toLowerCase()));

    if (!matchesLocation) return false; // Early exit if not matching location

    if (highlightedProductIds.length > 0) return isHighlighted && matchesSearch;

    // Store ID Filter (takes precedence over store type if selected)
    if (selectedStoreId) {
      return p.storeId === selectedStoreId && 
             (selectedCategory === 'All' || p.category === selectedCategory) &&
             matchesSearch;
    }

    const matchesStore = selectedStoreType === 'All' || p.storeType === selectedStoreType;
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    
    return matchesStore && matchesCategory && matchesSearch;
  });

  const handleAiSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;
    
    setAiLoading(true);
    setHighlightedProductIds([]);
    setSearchQuery(''); 
    setSelectedStoreId(null);
    
    const recommendedIds = await getShopperRecommendations(aiQuery, products);
    
    setHighlightedProductIds(recommendedIds);
    setAiLoading(false);
    
    if (recommendedIds.length === 0) {
      alert("AI couldn't find specific matches, but feel free to browse!");
    }
  };

  const clearAiSearch = () => {
    setHighlightedProductIds([]);
    setAiQuery('');
  };

  const handleStoreSelect = (type: StoreType | 'All') => {
    setSelectedStoreType(type);
    setSelectedStoreId(null); // Clear specific store selection
    setSelectedCategory('All');
  };

  const handleSpecificStoreSelect = (storeId: string) => {
    setSelectedStoreId(storeId);
    setSelectedStoreType('All'); // Reset broad type filter
    setSelectedCategory('All');
    setHighlightedProductIds([]); // Clear AI search
    setSearchQuery('');
  };

  const handleCheckoutClick = () => {
    if (!checkoutStreet || !checkoutPhone || !checkoutName || !checkoutCity) {
      alert("Please fill in all required delivery details.");
      return;
    }

    const fullAddress = `${checkoutName}
${checkoutStreet}
${checkoutCity}${checkoutZip ? `, ${checkoutZip}` : ''}
${checkoutInstructions ? `Note: ${checkoutInstructions}` : ''}`;

    onCheckout(fullAddress, checkoutPhone, selectedPaymentMethod);
    setIsCartOpen(false);
  };

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(profileForm);
    setIsProfileOpen(false);
  };

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStoreId || newReviewRating === 0) return;
    
    const review: Review = {
      id: Math.random().toString(36).substr(2, 9),
      storeId: selectedStoreId,
      userId: currentUser.id,
      userName: currentUser.name,
      rating: newReviewRating,
      comment: newReviewComment,
      timestamp: Date.now()
    };
    
    onAddReview(review);
    setIsReviewModalOpen(false);
    setNewReviewRating(0);
    setNewReviewComment('');
  };

  // Helper to close other drawers when one is opened
  const closeAllDrawers = () => {
    setIsCartOpen(false);
    setIsOrdersOpen(false);
    setIsProfileOpen(false);
    setIsMessagesOpen(false);
  };

  // Get current store aggregate rating
  const getCurrentStoreReviews = () => {
    if (!selectedStoreId) return [];
    return reviews.filter(r => r.storeId === selectedStoreId).sort((a, b) => b.timestamp - a.timestamp);
  };

  const getAverageRating = (storeId: string) => {
    const storeReviews = reviews.filter(r => r.storeId === storeId);
    if (storeReviews.length === 0) return 0;
    const sum = storeReviews.reduce((acc, r) => acc + r.rating, 0);
    return sum / storeReviews.length;
  };

  const renderStars = (rating: number, size = 16) => {
    return (
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star 
            key={star} 
            size={size} 
            className={`${star <= Math.round(rating) ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'}`} 
          />
        ))}
      </div>
    );
  };

  const currentStore = selectedStoreId ? stores.find(s => s.id === selectedStoreId) : null;
  const currentStoreReviews = getCurrentStoreReviews();
  const currentStoreAvgRating = selectedStoreId ? getAverageRating(selectedStoreId) : 0;
  
  // When a store is selected, we want a special layout
  const isStoreView = !!(selectedStoreId && currentStore);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 flex flex-col pb-16 md:pb-0 transition-colors duration-200">
      {/* Navbar */}
      <div className={`sticky top-0 z-40 transition-all ${isStoreView ? 'bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-100 dark:border-slate-800' : 'bg-transparent absolute w-full top-0'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => {handleStoreSelect('All'); clearAiSearch(); setSearchQuery('');}}>
            <div className={`h-9 w-9 rounded-xl flex items-center justify-center font-bold text-lg shadow-sm backdrop-blur-md ${isStoreView ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white' : 'bg-white/90 dark:bg-white/10 text-emerald-600 dark:text-white border border-white/20'}`}>D</div>
            <span className={`font-bold text-xl tracking-tight text-slate-900 dark:text-white drop-shadow-sm`}>Dolphin</span>
          </div>
          
          <div className="flex items-center gap-2 md:gap-6">
            {/* Location Selector */}
            <div className="relative hidden md:block">
              <button 
                onClick={() => setIsLocationOpen(!isLocationOpen)}
                className={`flex items-center text-sm px-3 py-1.5 rounded-full border transition-colors cursor-pointer text-slate-900 dark:text-slate-300 bg-white/60 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 hover:border-emerald-500 hover:bg-white dark:hover:bg-slate-800 backdrop-blur-sm shadow-sm`}
              >
                <MapPin className="w-4 h-4 mr-2 text-emerald-600 dark:text-emerald-500" />
                <span>Delivering to <span className="font-semibold text-slate-900 dark:text-white">{location}</span></span>
                <ChevronDown className="w-3 h-3 ml-1 text-slate-500 dark:text-slate-400"/>
              </button>
              
              {isLocationOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsLocationOpen(false)}></div>
                  <div className="absolute top-full right-0 mt-2 w-64 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-100 dark:border-slate-800 py-2 z-20 overflow-hidden">
                     <div className="px-3 pb-2 border-b border-slate-100 dark:border-slate-800 mb-2">
                       <div className="relative">
                         <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                         <input 
                           type="text" 
                           placeholder="Search city..." 
                           className="w-full pl-8 pr-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all text-black dark:text-white"
                           value={locationSearch}
                           onChange={(e) => setLocationSearch(e.target.value)}
                           autoFocus
                         />
                       </div>
                     </div>
                     <div className="max-h-60 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-slate-700">
                       <button 
                          onClick={() => { setLocation('Current Location'); setIsLocationOpen(false); }} 
                          className="w-full text-left px-4 py-2.5 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 text-emerald-600 font-medium flex items-center gap-2 transition-colors"
                        >
                          <MapPin size={14} /> Use Current Location
                        </button>
                        <div className="h-px bg-slate-100 dark:bg-slate-800 my-1"></div>
                        {filteredLocations.map(loc => (
                          <button 
                            key={loc} 
                            onClick={() => { setLocation(loc); setIsLocationOpen(false); }} 
                            className={`w-full text-left px-4 py-2.5 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center justify-between ${location === loc ? 'text-emerald-600 font-medium bg-emerald-50/50 dark:bg-emerald-900/20' : 'text-slate-600 dark:text-slate-400'}`}
                          >
                            {loc}
                            {location === loc && <span className="w-2 h-2 rounded-full bg-emerald-500"></span>}
                          </button>
                       ))}
                       {filteredLocations.length === 0 && (
                         <div className="px-4 py-3 text-sm text-slate-400 text-center">No cities found</div>
                       )}
                     </div>
                  </div>
                </>
              )}
            </div>

            <button 
              onClick={toggleTheme}
              className="p-2 rounded-full transition-colors hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>

            {/* Notification Button (Visible on Mobile too) */}
            <button 
              onClick={() => setIsNotificationsOpen(true)}
              className="relative p-2 rounded-full transition-all hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300 hover:text-emerald-600"
              title="Notifications"
            >
              <Bell className="w-6 h-6" />
              <span className="absolute top-1.5 right-2 h-2 w-2 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-900"></span>
            </button>

            <div className="hidden md:flex items-center gap-2">
              <button 
                onClick={() => {closeAllDrawers(); setIsMessagesOpen(true);}}
                className="relative p-2 rounded-full transition-all hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300 hover:text-emerald-600"
                title="Messages"
              >
                <MessageCircle className="w-6 h-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 h-2 w-2 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-900"></span>
                )}
              </button>

              <button 
                onClick={() => {closeAllDrawers(); setIsProfileOpen(true);}}
                className="relative p-2 rounded-full transition-all hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300 hover:text-emerald-600"
                title="My Profile"
              >
                <User className="w-6 h-6" />
              </button>

              <button 
                onClick={() => {closeAllDrawers(); setIsOrdersOpen(true);}}
                className="relative p-2 rounded-full transition-all hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300 hover:text-emerald-600"
                title="My Orders"
              >
                <Package className="w-6 h-6" />
              </button>

              <button 
                onClick={() => {closeAllDrawers(); setIsCartOpen(true);}}
                className="relative p-2 rounded-full transition-all group hover:bg-black/5 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-300"
              >
                <ShoppingCart className="w-6 h-6 transition-colors group-hover:text-emerald-600 dark:group-hover:text-emerald-400" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-emerald-500 text-white text-[10px] font-bold h-5 w-5 rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* COOL HERO SECTION - Only show when NOT in single store view */}
      {!isStoreView && (
        <div className="relative overflow-hidden bg-gradient-to-br from-indigo-100 via-white to-emerald-100 dark:from-slate-900 dark:via-emerald-950 dark:to-indigo-950 min-h-[550px] flex items-center pt-16">
          {/* Animated Background Mesh */}
          <div className="absolute inset-0 bg-grid-pattern opacity-60 dark:opacity-20 z-0 animate-pulse-slow"></div>
          
          {/* Abstract blobs */}
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 dark:bg-emerald-500/20 rounded-full blur-[100px] animate-float"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-500/10 dark:bg-indigo-500/20 rounded-full blur-[100px] animate-float-delayed"></div>
          
          {/* Floating Icons for 3D effect */}
          <div className="absolute top-[15%] left-[10%] text-emerald-600/30 dark:text-emerald-400/30 animate-float hidden md:block">
             <ShoppingCart size={64} />
          </div>
          <div className="absolute bottom-[20%] left-[20%] text-indigo-600/30 dark:text-indigo-400/30 animate-float-delayed hidden md:block">
             <Store size={48} />
          </div>
          <div className="absolute top-[20%] right-[15%] text-teal-600/30 dark:text-teal-400/30 animate-float-delayed hidden md:block">
             <Zap size={56} />
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center z-10 w-full">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/60 dark:bg-white/10 backdrop-blur-md border border-slate-300 dark:border-white/20 text-emerald-800 dark:text-emerald-300 text-xs font-bold mb-6 animate-in slide-in-from-bottom fade-in duration-700 shadow-sm">
              <Sparkles size={12} className="text-emerald-600 dark:text-emerald-400"/>
              <span>AI-Powered Local Shopping</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-slate-950 dark:text-white mb-6 tracking-tight leading-tight animate-in slide-in-from-bottom fade-in duration-700 delay-100 drop-shadow-sm">
              Discover your <br className="md:hidden" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600 dark:from-emerald-400 dark:to-cyan-400">Neighborhood's Best.</span>
            </h1>
            
            <p className="text-slate-700 dark:text-slate-300 mb-10 text-lg max-w-2xl mx-auto animate-in slide-in-from-bottom fade-in duration-700 delay-200 font-medium">
              From fresh groceries to electronics, find everything local stores have to offer. delivered in minutes.
            </p>

            <form onSubmit={handleAiSearch} className="relative max-w-3xl mx-auto group animate-in slide-in-from-bottom fade-in duration-700 delay-300">
              <div className="relative transform transition-all duration-300 hover:scale-[1.01]">
                {/* Glow Effect */}
                <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-indigo-500 rounded-full blur opacity-10 dark:opacity-30 group-hover:opacity-30 dark:group-hover:opacity-60 transition duration-500"></div>
                
                {/* Glass Search Bar */}
                <div className="relative bg-white/90 dark:bg-white/10 backdrop-blur-xl border border-slate-300 dark:border-white/20 rounded-full shadow-xl dark:shadow-2xl flex items-center p-2">
                  <div className="pl-4 text-emerald-600 dark:text-emerald-400">
                    <Sparkles className="w-6 h-6 animate-pulse" />
                  </div>
                  <input 
                    type="text" 
                    value={aiQuery}
                    onChange={e => setAiQuery(e.target.value)}
                    placeholder="Ask Dolphin: 'I need ingredients for tacos' or 'Best headphones nearby'..."
                    className="w-full pl-4 pr-4 py-4 text-lg text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 outline-none bg-transparent font-medium"
                  />
                  {highlightedProductIds.length > 0 && (
                    <button 
                      type="button"
                      onClick={clearAiSearch}
                      className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-full transition-colors mr-2"
                    >
                      <X size={20} />
                    </button>
                  )}
                  <button 
                    type="submit"
                    disabled={aiLoading}
                    className="bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white px-8 py-3 rounded-full font-bold transition-all shadow-lg hover:shadow-emerald-500/25 disabled:opacity-70 disabled:cursor-wait min-w-[120px]"
                  >
                    {aiLoading ? (
                      <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div>
                    ) : (
                      'Find'
                    )}
                  </button>
                </div>
              </div>
            </form>

            {/* Quick Chips */}
            <div className="mt-8 flex flex-wrap justify-center gap-2 animate-in slide-in-from-bottom fade-in duration-700 delay-500">
              {['Fruits', 'Bakery', 'Medicines', 'Shoes'].map((chip, idx) => (
                <button 
                  key={idx}
                  onClick={() => { setAiQuery(chip); handleAiSearch({ preventDefault: () => {} } as any); }}
                  className="px-4 py-1.5 rounded-full bg-white dark:bg-white/5 hover:bg-slate-50 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 text-sm text-slate-700 dark:text-slate-300 hover:text-emerald-700 dark:hover:text-white transition-all cursor-pointer backdrop-blur-sm shadow-sm font-medium"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>
          
          {/* Curve Divider at bottom */}
          <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none z-20">
             <svg className="relative block w-full h-[60px] md:h-[100px] text-slate-100 dark:text-slate-950" viewBox="0 0 1200 120" preserveAspectRatio="none">
                 <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" fill="currentColor"></path>
             </svg>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full flex-grow">
        
        {isStoreView ? (
          // STOREFRONT VIEW (Single Store)
          <div className="animate-in fade-in duration-500">
             {/* Back to Marketplace */}
             <div className="mb-4">
                <button 
                  onClick={() => handleStoreSelect('All')}
                  className="inline-flex items-center text-sm font-medium text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors"
                >
                   <ChevronLeft size={16} className="mr-1" /> Back to Marketplace
                </button>
             </div>

             {/* Hero Banner */}
             <div className="relative h-48 md:h-64 rounded-3xl overflow-hidden mb-8 shadow-lg">
                <img 
                   src={STORE_IMAGES[currentStore.type]} 
                   alt={currentStore.name} 
                   className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6 md:p-8">
                   <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-lg text-white text-xs font-bold uppercase tracking-wide border border-white/20 mb-3">
                      {currentStore.type} Store
                   </span>
                   <h1 className="text-3xl md:text-5xl font-bold text-white drop-shadow-md">{currentStore.name}</h1>
                </div>
             </div>

             <div className="flex flex-col lg:flex-row gap-8">
                {/* Left Sidebar - Store Info */}
                <div className="w-full lg:w-80 flex-shrink-0 space-y-6">
                   <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800 lg:sticky lg:top-24">
                      <div className="space-y-4">
                         <div className="flex items-start gap-3">
                            <MapPin className="text-slate-400 mt-1 shrink-0" size={20} />
                            <div>
                               <h3 className="font-semibold text-slate-900 dark:text-white">Address</h3>
                               <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{currentStore.address}</p>
                            </div>
                         </div>
                         
                         <div className="flex items-start gap-3">
                            <Phone className="text-slate-400 mt-1 shrink-0" size={20} />
                            <div>
                               <h3 className="font-semibold text-slate-900 dark:text-white">Contact</h3>
                               <p className="text-slate-500 dark:text-slate-400 text-sm">{currentStore.phoneNumber || 'No phone provided'}</p>
                            </div>
                         </div>

                         <div className="flex items-start gap-3">
                            <Clock className="text-slate-400 mt-1 shrink-0" size={20} />
                            <div>
                               <h3 className="font-semibold text-slate-900 dark:text-white">Hours</h3>
                               <p className="text-slate-500 dark:text-slate-400 text-sm text-emerald-600 font-medium">Open Now • Closes 9 PM</p>
                            </div>
                         </div>

                         <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                            <div className="flex items-center gap-2 mb-2">
                               <span className="text-2xl font-bold text-slate-900 dark:text-white">{currentStoreAvgRating.toFixed(1)}</span>
                               {renderStars(currentStoreAvgRating)}
                               <span className="text-sm text-slate-400">({currentStoreReviews.length})</span>
                            </div>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="w-full mb-3"
                              onClick={() => setIsReviewModalOpen(true)}
                            >
                               Write a Review
                            </Button>
                            
                            <Button 
                               className="w-full"
                               onClick={() => openChatWithStore(currentStore.id)}
                               icon={<MessageCircle size={18} />}
                            >
                               Chat with Store
                            </Button>
                         </div>
                      </div>
                   </div>

                   {/* Reviews Preview (Sidebar) */}
                   {currentStoreReviews.length > 0 && (
                      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-800">
                         <h3 className="font-bold text-slate-900 dark:text-white mb-4">Recent Reviews</h3>
                         <div className="space-y-4">
                            {currentStoreReviews.slice(0, 2).map(review => (
                               <div key={review.id} className="pb-4 border-b border-slate-50 dark:border-slate-800 last:border-0 last:pb-0">
                                  <div className="flex justify-between items-center mb-1">
                                     <span className="font-medium text-sm text-slate-900 dark:text-white">{review.userName}</span>
                                     <span className="text-xs text-slate-400">{new Date(review.timestamp).toLocaleDateString()}</span>
                                  </div>
                                  <div className="mb-1">{renderStars(review.rating, 12)}</div>
                                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{review.comment}</p>
                               </div>
                            ))}
                         </div>
                      </div>
                   )}
                </div>

                {/* Right Content - Products */}
                <div className="flex-1">
                   {/* Local Search & Filter */}
                   <div className="flex flex-col sm:flex-row gap-4 mb-6 sticky top-16 z-30 bg-slate-100/95 dark:bg-slate-950/95 backdrop-blur-sm py-2">
                      <div className="relative flex-1">
                         <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                         <input 
                            type="text" 
                            placeholder={`Search in ${currentStore.name}...`}
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-slate-900 dark:text-white"
                         />
                      </div>
                      <select 
                        className="px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white cursor-pointer"
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                      >
                         <option value="All">All Categories</option>
                         {STORE_CATEGORIES[currentStore.type]?.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                         ))}
                      </select>
                   </div>

                   {/* Product Grid */}
                   <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredProducts.map(product => {
                         const isInCart = cart.some(item => item.id === product.id);
                         return (
                            <div key={product.id} className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden group hover:shadow-md transition-all">
                               <div className="relative h-48 overflow-hidden bg-slate-100 dark:bg-slate-800">
                                  <img 
                                     src={product.imageUrl} 
                                     alt={product.name} 
                                     className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                                  />
                                  {product.stock <= 5 && (
                                     <span className="absolute top-2 left-2 bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm">
                                        Only {product.stock} left
                                     </span>
                                  )}
                               </div>
                               <div className="p-4">
                                  <div className="flex justify-between items-start mb-2">
                                     <div>
                                        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mb-0.5">{product.category}</p>
                                        <h3 className="font-bold text-slate-900 dark:text-white leading-tight line-clamp-1">{product.name}</h3>
                                     </div>
                                     <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{product.price}</span>
                                  </div>
                                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 h-8">{product.description}</p>
                                  <Button 
                                     onClick={() => onAddToCart(product)} 
                                     className="w-full" 
                                     size="sm"
                                     variant={isInCart ? "secondary" : "primary"}
                                  >
                                     {isInCart ? 'Add Another' : 'Add to Cart'}
                                  </Button>
                               </div>
                            </div>
                         );
                      })}
                   </div>

                   {filteredProducts.length === 0 && (
                      <div className="text-center py-20">
                         <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-200 dark:bg-slate-800 mb-4">
                            <Search className="text-slate-400" size={32} />
                         </div>
                         <h3 className="text-lg font-medium text-slate-900 dark:text-white">No products found</h3>
                         <p className="text-slate-500 dark:text-slate-400">Try adjusting your search or category filter.</p>
                      </div>
                   )}
                </div>
             </div>
          </div>
        ) : (
          // MARKETPLACE HOME VIEW
          <div className="space-y-12">
            
            {/* Store Categories - Quick Nav */}
            <div className="space-y-4">
               <div className="flex items-center justify-between px-2">
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">Shop by Category</h2>
               </div>
               <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide px-2">
                  <button 
                     onClick={() => handleStoreSelect('All')}
                     className={`flex flex-col items-center min-w-[80px] group ${selectedStoreType === 'All' ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`}
                  >
                     <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-2 transition-all shadow-sm ${selectedStoreType === 'All' ? 'bg-emerald-600 text-white shadow-emerald-200 dark:shadow-none' : 'bg-white dark:bg-slate-800 text-slate-400 border border-slate-200 dark:border-slate-700'}`}>
                        <Store size={28} />
                     </div>
                     <span className="text-xs font-medium text-slate-700 dark:text-slate-300">All</span>
                  </button>
                  {STORE_TYPES.map(type => (
                     <button 
                        key={type}
                        onClick={() => handleStoreSelect(type)}
                        className={`flex flex-col items-center min-w-[80px] group ${selectedStoreType === type ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`}
                     >
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-2 transition-all shadow-sm overflow-hidden border-2 ${selectedStoreType === type ? 'border-emerald-500' : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800'}`}>
                           <img src={STORE_IMAGES[type]} alt={type} className="w-full h-full object-cover" />
                        </div>
                        <span className="text-xs font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap">{type}</span>
                     </button>
                  ))}
               </div>
            </div>

            {/* Featured Stores */}
            <div className="space-y-4">
               <div className="flex items-center justify-between px-2">
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">Featured Stores Nearby</h2>
                  <button className="text-emerald-600 dark:text-emerald-400 text-sm font-medium hover:underline">View All</button>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {stores
                    .filter(s => selectedStoreType === 'All' || s.type === selectedStoreType)
                    .filter(s => location === 'Current Location' || s.address.toLowerCase().includes(location.toLowerCase()))
                    .slice(0, 6)
                    .map(store => (
                     <div 
                        key={store.id} 
                        onClick={() => handleSpecificStoreSelect(store.id)}
                        className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden hover:shadow-xl transition-all group cursor-pointer h-full flex flex-col"
                     >
                        <div className="h-40 relative overflow-hidden">
                           <img 
                              src={STORE_IMAGES[store.type]} 
                              alt={store.name} 
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                           />
                           <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                           <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                              <span className="bg-white/20 backdrop-blur-md border border-white/20 text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                                 {store.type}
                              </span>
                              <div className="flex items-center bg-black/40 backdrop-blur-sm rounded-lg px-1.5 py-0.5">
                                 <Star size={12} className="text-amber-400 fill-amber-400 mr-1" />
                                 <span className="text-white text-xs font-bold">{getAverageRating(store.id).toFixed(1)}</span>
                              </div>
                           </div>
                        </div>
                        <div className="p-4 flex-1 flex flex-col">
                           <h3 className="font-bold text-lg text-slate-900 dark:text-white mb-1 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">{store.name}</h3>
                           <p className="text-sm text-slate-500 dark:text-slate-400 flex items-start gap-1.5 mb-4">
                              <MapPin size={14} className="mt-0.5 shrink-0" /> {store.address}
                           </p>
                           <div className="mt-auto pt-4 border-t border-slate-50 dark:border-slate-800 flex items-center justify-between">
                              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-1 rounded">Open Now</span>
                              <span className="text-xs text-slate-400">1.2 km away</span>
                           </div>
                        </div>
                     </div>
                  ))}
               </div>
               {stores.filter(s => location === 'Current Location' || s.address.toLowerCase().includes(location.toLowerCase())).length === 0 && (
                  <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                     <MapPin className="mx-auto text-slate-300 dark:text-slate-600 mb-2" size={32} />
                     <p className="text-slate-500 dark:text-slate-400">No stores found in {location}. Try changing location.</p>
                  </div>
               )}
            </div>

            {/* Recent/Popular Products */}
            <div className="space-y-4">
               <div className="flex items-center justify-between px-2">
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">Popular Items</h2>
               </div>
               
               <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {filteredProducts.slice(0, 8).map(product => {
                     const isInCart = cart.some(item => item.id === product.id);
                     return (
                        <div key={product.id} className={`bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border transition-all hover:shadow-md ${highlightedProductIds.includes(product.id) ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-slate-200 dark:border-slate-800'}`}>
                           <div className="relative aspect-square mb-4 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 group">
                              <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                              <button 
                                 className="absolute bottom-2 right-2 p-2 bg-white dark:bg-slate-900 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity text-emerald-600"
                                 onClick={() => onAddToCart(product)}
                              >
                                 <Plus size={16} />
                              </button>
                           </div>
                           <h3 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1 mb-1">{product.name}</h3>
                           <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">{product.storeName}</p>
                           <div className="flex items-center justify-between">
                              <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{product.price}</span>
                              {isInCart && <span className="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 px-1.5 py-0.5 rounded">In Cart</span>}
                           </div>
                        </div>
                     );
                  })}
               </div>
            </div>

             {/* COMPANY FOOTER */}
             <div className="mt-16 py-8 border-t border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center text-center opacity-60 hover:opacity-100 transition-opacity">
                <div className="flex items-center gap-2 mb-2">
                   <div className="h-6 w-6 rounded bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-500 dark:text-slate-400">G</div>
                   <span className="font-bold text-slate-700 dark:text-slate-300">Gwalvanshi Private Limited</span>
                </div>
                <p className="text-xs text-slate-400">App Since 2025 • All Rights Reserved</p>
             </div>
          </div>
        )}
      </div>

      {/* MOBILE BOTTOM NAV */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 z-50 pb-safe shadow-lg">
        <div className="flex justify-around items-center h-16">
          <button onClick={() => {handleStoreSelect('All'); setSelectedStoreId(null);}} className={`flex flex-col items-center justify-center w-full h-full active:scale-95 transition-transform ${!selectedStoreId ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'}`}>
            <Home size={24} />
            <span className="text-[10px] mt-1 font-medium">Home</span>
          </button>
          <button onClick={() => {closeAllDrawers(); setIsCartOpen(true);}} className="flex flex-col items-center justify-center w-full h-full active:scale-95 transition-transform text-slate-500 dark:text-slate-400 relative">
            <ShoppingCart size={24} />
            <span className="text-[10px] mt-1 font-medium">Cart</span>
            {cartCount > 0 && <span className="absolute top-3 right-8 bg-emerald-500 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center">{cartCount}</span>}
          </button>
          <button onClick={() => {closeAllDrawers(); setIsOrdersOpen(true);}} className="flex flex-col items-center justify-center w-full h-full active:scale-95 transition-transform text-slate-500 dark:text-slate-400">
            <Package size={24} />
            <span className="text-[10px] mt-1 font-medium">Orders</span>
          </button>
          <button onClick={() => {closeAllDrawers(); setIsProfileOpen(true);}} className="flex flex-col items-center justify-center w-full h-full active:scale-95 transition-transform text-slate-500 dark:text-slate-400">
            <User size={24} />
            <span className="text-[10px] mt-1 font-medium">Profile</span>
          </button>
        </div>
      </div>

      {/* --- DRAWERS & MODALS --- */}

      {/* CART DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsCartOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 z-10">
              <div className="flex items-center gap-2">
                 <button onClick={() => setIsCartOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full md:hidden">
                    <ChevronLeft size={24} />
                 </button>
                 <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <ShoppingCart size={20} /> Your Cart
                 </h2>
              </div>
              <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400">
                <X size={24} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-4">
                  <div className="w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center">
                     <ShoppingCart size={40} className="text-slate-300 dark:text-slate-600" />
                  </div>
                  <p className="font-medium">Your cart is empty</p>
                  <Button variant="secondary" onClick={() => setIsCartOpen(false)}>Start Shopping</Button>
                </div>
              ) : (
                <>
                {/* Cart Items */}
                <div className="space-y-4 mb-6">
                  {cart.map(item => (
                    <div key={item.id} className="flex gap-4 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                      <img src={item.imageUrl} alt={item.name} className="w-20 h-20 rounded-lg object-cover bg-slate-100 dark:bg-slate-800" />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                             <h4 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1">{item.name}</h4>
                             <p className="text-xs text-slate-500 dark:text-slate-400">{item.storeName}</p>
                          </div>
                          <button onClick={() => onRemoveFromCart(item.id)} className="text-rose-500 p-1 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded">
                             <X size={14} />
                          </button>
                        </div>
                        <div className="flex justify-between items-end mt-2">
                          <span className="font-bold text-emerald-600 dark:text-emerald-400">₹{item.price}</span>
                          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg px-2 py-1">
                            <span className="text-xs font-bold text-slate-900 dark:text-white">Qty: {item.quantity}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Delivery Form */}
                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
                   <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                      <MapPin size={16} className="text-emerald-500" /> Delivery Details
                   </h3>
                   
                   <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Name</label>
                        <input 
                           type="text" 
                           placeholder="Receiver Name" 
                           className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                           value={checkoutName}
                           onChange={(e) => setCheckoutName(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Phone</label>
                        <input 
                           type="tel" 
                           placeholder="Mobile No." 
                           className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                           value={checkoutPhone}
                           onChange={(e) => setCheckoutPhone(e.target.value)}
                        />
                      </div>
                   </div>

                   <div>
                      <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Street Address</label>
                      <textarea 
                        rows={2} 
                        placeholder="House No, Street, Landmark..." 
                        className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white resize-none"
                        value={checkoutStreet}
                        onChange={(e) => setCheckoutStreet(e.target.value)}
                      />
                   </div>

                   <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">City</label>
                        <input 
                           type="text" 
                           placeholder="City" 
                           className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                           value={checkoutCity}
                           onChange={(e) => setCheckoutCity(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Zip Code</label>
                        <input 
                           type="text" 
                           placeholder="Zip Code" 
                           className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white"
                           value={checkoutZip}
                           onChange={(e) => setCheckoutZip(e.target.value)}
                        />
                      </div>
                   </div>

                   <div>
                      <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Instructions (Optional)</label>
                      <textarea 
                        rows={1} 
                        placeholder="e.g. Leave at door, Ring bell..." 
                        className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white resize-none"
                        value={checkoutInstructions}
                        onChange={(e) => setCheckoutInstructions(e.target.value)}
                      />
                   </div>
                </div>

                {/* Payment Selection */}
                <div className="space-y-2">
                   <label className="text-xs font-bold uppercase text-slate-500">Payment Method</label>
                   <div className="grid grid-cols-2 gap-2">
                      {paymentMethods.map(pm => (
                         <button
                           key={pm.id}
                           onClick={() => setSelectedPaymentMethod(pm.id)}
                           className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${selectedPaymentMethod === pm.id ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800'}`}
                         >
                            <pm.icon size={20} className="mb-1" />
                            <span className="text-[10px] font-bold">{pm.name}</span>
                         </button>
                      ))}
                   </div>
                </div>
                </>
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)]">
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between text-slate-600 dark:text-slate-400 text-sm">
                    <span>Subtotal</span>
                    <span>₹{cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-400 text-sm">
                    <span>Delivery Fee</span>
                    <span>₹40.00</span>
                  </div>
                  <div className="flex justify-between text-xl font-bold text-slate-900 dark:text-white pt-3 border-t border-slate-200 dark:border-slate-700">
                    <span>Total</span>
                    <span>₹{(cartTotal + 40).toFixed(2)}</span>
                  </div>
                </div>

                <Button onClick={handleCheckoutClick} className="w-full py-4 text-base shadow-emerald-500/20 shadow-lg font-bold">
                   Place Order • ₹{(cartTotal + 40).toFixed(2)}
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ORDERS DRAWER */}
      {isOrdersOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsOrdersOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
               <div className="flex items-center gap-2">
                 <button onClick={() => setIsOrdersOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full md:hidden">
                    <ChevronLeft size={24} />
                 </button>
                 <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <Package size={20} /> My Orders
                 </h2>
              </div>
              <button onClick={() => setIsOrdersOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400">
                <X size={24} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
               {orders.length === 0 ? (
                  <div className="text-center py-10 text-slate-500">
                     <Package size={48} className="mx-auto mb-4 opacity-20" />
                     <p>No past orders found.</p>
                  </div>
               ) : (
                  orders.map(order => (
                    <div key={order.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
                       <div className="flex justify-between items-start mb-3">
                          <div>
                             <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold uppercase mb-1 ${
                                order.status === 'delivered' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' :
                                order.status === 'cancelled' ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-400' :
                                'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
                             }`}>
                                {order.status}
                             </span>
                             <p className="text-xs text-slate-400">#{order.id.slice(0, 8)}</p>
                          </div>
                          <span className="font-bold text-slate-900 dark:text-white">₹{order.total.toFixed(2)}</span>
                       </div>
                       
                       <div className="space-y-2 mb-4">
                          {order.items.map(item => (
                             <div key={item.id} className="flex justify-between text-sm text-slate-600 dark:text-slate-400">
                                <span>{item.quantity}x {item.name}</span>
                                <span>₹{item.price * item.quantity}</span>
                             </div>
                          ))}
                       </div>
                       
                       <div className="pt-3 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                          <span className="text-xs text-slate-400">{new Date(order.timestamp).toLocaleDateString()}</span>
                          {order.status === 'pending' && (
                             <Button size="sm" variant="danger" onClick={() => onCancelOrder(order.id)}>Cancel Order</Button>
                          )}
                       </div>
                    </div>
                  ))
               )}
            </div>
          </div>
        </div>
      )}

      {/* PROFILE DRAWER */}
      {isProfileOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsProfileOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
               <div className="flex items-center gap-2">
                 <button onClick={() => setIsProfileOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full md:hidden">
                    <ChevronLeft size={24} />
                 </button>
                 <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <User size={20} /> My Profile
                 </h2>
              </div>
              <button onClick={() => setIsProfileOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400">
                <X size={24} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6">
               <div className="flex flex-col items-center mb-8">
                  <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/20 rounded-full flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-3 text-3xl font-bold shadow-inner overflow-hidden">
                     {currentUser.photoURL ? (
                        <img src={currentUser.photoURL} alt="Profile" className="w-full h-full object-cover" />
                     ) : (
                        currentUser.name.charAt(0)
                     )}
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">{currentUser.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400">{currentUser.email}</p>
               </div>

               <form onSubmit={handleProfileSave} className="space-y-5">
                  <div>
                     <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Full Name</label>
                     <input 
                        type="text" 
                        value={profileForm.name}
                        onChange={e => setProfileForm({...profileForm, name: e.target.value})}
                        className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Phone Number</label>
                     <input 
                        type="tel" 
                        value={profileForm.phoneNumber}
                        onChange={e => setProfileForm({...profileForm, phoneNumber: e.target.value})}
                        className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                        placeholder="+91 98765 43210"
                     />
                  </div>
                  <div>
                     <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Delivery Address</label>
                     <textarea 
                        rows={3}
                        value={profileForm.address}
                        onChange={e => setProfileForm({...profileForm, address: e.target.value})}
                        className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                        placeholder="123 Main St, City"
                     />
                  </div>
                  
                  <div className="pt-4 space-y-3">
                     <Button type="submit" className="w-full">Save Changes</Button>
                     
                     <div id="install-button-container" className="pt-2">
                        {/* Install App button will be injected here if supported */}
                     </div>
                  </div>
               </form>
               
               <div className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800">
                  <button onClick={onLogout} className="flex items-center gap-2 text-rose-500 font-medium hover:text-rose-600 transition-colors mx-auto">
                     <LogOut size={18} /> Sign Out
                  </button>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* MESSAGES DRAWER */}
      {isMessagesOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
           <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsMessagesOpen(false)}></div>
           <div className="relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 z-10">
                 <div className="flex items-center gap-2">
                    <button onClick={() => setIsMessagesOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full md:hidden">
                       <ChevronLeft size={24} />
                    </button>
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                       <MessageCircle size={20} /> Messages
                    </h2>
                 </div>
                 <button onClick={() => setIsMessagesOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400">
                   <X size={24} />
                 </button>
              </div>

              {!activeChatPartnerId ? (
                 // Chat List
                 <div className="flex-1 overflow-y-auto">
                    {contactIds.length === 0 ? (
                       <div className="text-center py-10 px-6">
                          <MessageCircle size={48} className="mx-auto text-slate-300 dark:text-slate-600 mb-4" />
                          <p className="text-slate-500 dark:text-slate-400">No messages yet. Chat with a store from their profile page.</p>
                       </div>
                    ) : (
                       contactIds.map(id => {
                          const lastMsg = myMessages
                             .filter(m => (m.senderId === id || m.receiverId === id))
                             .sort((a, b) => b.timestamp - a.timestamp)[0];
                          const store = getStoreByOwnerId(id);
                          const name = store ? store.name : 'Store Owner';
                          
                          return (
                             <div 
                                key={id}
                                onClick={() => setActiveChatPartnerId(id)}
                                className="p-4 border-b border-slate-50 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer transition-colors"
                             >
                                <div className="flex justify-between items-baseline mb-1">
                                   <h4 className="font-bold text-slate-900 dark:text-white">{name}</h4>
                                   <span className="text-xs text-slate-400">{new Date(lastMsg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                </div>
                                <p className="text-sm text-slate-500 dark:text-slate-400 truncate">{lastMsg.content}</p>
                             </div>
                          );
                       })
                    )}
                 </div>
              ) : (
                 // Active Chat
                 <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-50 dark:bg-slate-950">
                    <div className="bg-white dark:bg-slate-900 px-4 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2 shadow-sm z-10">
                       <button onClick={() => setActiveChatPartnerId(null)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full">
                          <ChevronLeft size={20} />
                       </button>
                       <span className="font-bold text-slate-900 dark:text-white">{getStoreByOwnerId(activeChatPartnerId)?.name || 'Chat'}</span>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                       {activeChatMessages.map(msg => (
                          <div key={msg.id} className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                             <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-sm ${
                                msg.senderId === currentUser.id 
                                ? 'bg-emerald-600 text-white rounded-br-none' 
                                : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-bl-none'
                             }`}>
                                <p>{msg.content}</p>
                                <span className={`text-[10px] block text-right mt-1 ${msg.senderId === currentUser.id ? 'text-emerald-200' : 'text-slate-400'}`}>
                                   {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </span>
                             </div>
                          </div>
                       ))}
                       <div ref={messagesEndRef} />
                    </div>

                    <form onSubmit={handleSendMessageSubmit} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 flex gap-2">
                       <input 
                          type="text" 
                          value={messageInput}
                          onChange={(e) => setMessageInput(e.target.value)}
                          placeholder="Type a message..."
                          className="flex-1 bg-slate-100 dark:bg-slate-800 border-0 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none text-slate-900 dark:text-white"
                       />
                       <button 
                          type="submit"
                          disabled={!messageInput.trim()}
                          className="p-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                       >
                          <Send size={20} />
                       </button>
                    </form>
                 </div>
              )}
           </div>
        </div>
      )}

      {/* NOTIFICATIONS DRAWER */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
           <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsNotificationsOpen(false)}></div>
           <div className="relative w-full max-w-md bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col transform transition-transform animate-in slide-in-from-right duration-300">
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 z-10">
                 <div className="flex items-center gap-2">
                    <button onClick={() => setIsNotificationsOpen(false)} className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full md:hidden">
                       <ChevronLeft size={24} />
                    </button>
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                       <Bell size={20} /> Notifications
                    </h2>
                 </div>
                 <button onClick={() => setIsNotificationsOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full text-slate-400">
                   <X size={24} />
                 </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl border border-emerald-100 dark:border-emerald-800/30">
                     <div className="flex gap-3">
                        <div className="h-10 w-10 bg-emerald-100 dark:bg-emerald-800 rounded-full flex items-center justify-center text-emerald-600 dark:text-emerald-300 flex-shrink-0">
                           <Tag size={20} />
                        </div>
                        <div>
                           <h4 className="font-bold text-slate-900 dark:text-white text-sm">Welcome to Dolphin!</h4>
                           <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Get 20% off your first order with code WELCOME20.</p>
                           <span className="text-xs text-slate-400 mt-2 block">Just now</span>
                        </div>
                     </div>
                  </div>
              </div>
           </div>
        </div>
      )}

      {/* REVIEW MODAL */}
      {isReviewModalOpen && (
         <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={() => setIsReviewModalOpen(false)}></div>
            <div className="relative bg-white dark:bg-slate-900 rounded-2xl w-full max-w-sm p-6 shadow-2xl transform transition-all animate-in zoom-in-95 duration-200">
               <div className="text-center mb-6">
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white">Rate your experience</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">How was your visit to {currentStore?.name}?</p>
               </div>
               
               <div className="flex justify-center gap-2 mb-6">
                  {[1,2,3,4,5].map(star => (
                     <button 
                        key={star}
                        onClick={() => setNewReviewRating(star)}
                        className="transition-transform hover:scale-110 focus:outline-none"
                     >
                        <Star 
                           size={32} 
                           className={`${star <= newReviewRating ? 'fill-amber-400 text-amber-400' : 'text-slate-200 dark:text-slate-700'}`} 
                        />
                     </button>
                  ))}
               </div>
               
               <textarea 
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 mb-4 outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 dark:text-white resize-none"
                  rows={3}
                  placeholder="Share your feedback..."
                  value={newReviewComment}
                  onChange={e => setNewReviewComment(e.target.value)}
               />
               
               <div className="flex gap-3">
                  <Button variant="ghost" className="flex-1" onClick={() => setIsReviewModalOpen(false)}>Cancel</Button>
                  <Button className="flex-1" onClick={submitReview} disabled={newReviewRating === 0}>Submit</Button>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};